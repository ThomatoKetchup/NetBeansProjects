/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package traducteur;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.text.Text;
 
/**
 * 
 *
 * @author Alexandre
 */
public class FXMLDocumentController {

@FXML
private ToggleGroup toggleGroupIn;
@FXML
private ToggleGroup toggleGroupOut;

@FXML
private TextArea outputTextArea;  

@FXML 
private TextArea inputTextArea;

private Model model = new Model();
//completer le 

@FXML
private void processTranslation(ActionEvent event){
    String inLan = ((ToggleButton) toggleGroupIn.getSelectedToggle()).getText();
    String outLan = ((ToggleButton) toggleGroupOut.getSelectedToggle()).getText();
    String text = ((TextArea)inputTextArea).getText();		 
        
    
    (outputTextArea).setText(model.translate(text, inLan, outLan));	

} 
}  
    
